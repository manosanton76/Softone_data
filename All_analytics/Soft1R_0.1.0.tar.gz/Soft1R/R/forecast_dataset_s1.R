


#' Apply forecasting in a dataset
#'
#' @description
#' It can generate yearly|monthly|weekly|daily forecasts, with/without anomaly detection
#' in one continuous variable of the dataset
#'
#' @param final_dataset Specify the dataframe
#' @param periods Specify the forecasting period (year, month, week, day)
#' @param from Specify the starting date
#' @param to Specify the ending date
#' @param forecasts Specify number of future forecasts
#' @param nas Specify the function to replace the missing values
#' @param anomaly Indicate whether or not to use anomaly detection prior to forecasting
#' @param col Specify the numerical variable to forecast
#'
#' @details
#'
#' - Must provide a dataframe with at least a numerical variable (to forecast) and a date variable (must be named "date")
#'
#'
#' @examples
#' \dontrun{
#'
#' library(Soft1R)
#' library(tidyverse)
#' library(lubridate)
#'
#' t <- forecast_dataset_s1(final_dataset = vmtrstat_test, periods = "month", from = min(vmtrstat_test$date), to = max(vmtrstat_test$date), forecasts = 12, nas = "mean", anomaly = FALSE, col = salesval)
#' t
#' }
#'
#' @export
#'
forecast_dataset_s1 <- function(final_dataset = vmtrstat, periods = "month", from = min(vmtrstat$date), to = max(vmtrstat$date), forecasts = 12, nas = "mean", anomaly = FALSE, col){

  # final_dataset = vmtrstat
  # periods = "month"
  # from = min(vmtrstat$date)
  # to = max(vmtrstat$date)
  # forecasts = 12
  # nas = "mean"
  # anomaly = FALSE

  # Arguments
  if(nas == "mean") {
    na_values <- mean
  } else if (nas == "median") {

    na_values <- stats::median
  }

  periods <- periods
  from <- as.Date(from)
  to <- as.Date(to)
  forecasts <- forecasts
  anomaly <- anomaly

  # Dataset
  col <- dplyr::enquo(col)            # quote

  final_dataset <-
    final_dataset %>%
    #mutate(metric = salesval)
    #mutate(metric = credit)
    dplyr::mutate(metric = !!col)


  # _Month ------------------------------------------------------------------


  #Inputs
  if (periods == "month") {
    data <-
      final_dataset %>%
      dplyr::filter(date >= as.Date(from) & date <= as.Date(to)) %>%
      dplyr::mutate(date = lubridate::floor_date(as.Date(date), unit = periods)) %>%
      # dplyr::filter(date >= from & date <= to) %>%
      dplyr::group_by(date, .drop = FALSE) %>%
      dplyr::summarise(metric = sum(metric)) %>%
      dplyr::ungroup() %>%
      dplyr::full_join(data.frame(date = seq(lubridate::floor_date(as.Date(from), unit = periods), lubridate::floor_date(as.Date(to), unit = periods), by = periods))) %>%
      dplyr::arrange(date) %>%
      tidyr::replace_na(list(metric = na_values(.$metric, na.rm = TRUE))) %>%
      dplyr::mutate(metric = dplyr::if_else(metric == 0, dplyr::lag(metric, default = 0), metric))

    # Run when anomaly is selected
    if (anomaly == TRUE) {
      data <-
        data %>%
        anomalize::time_decompose(metric, merge = TRUE) %>%
        anomalize::anomalize(remainder) %>%
        anomalize::time_recompose() %>%
        dplyr::mutate(metric = ifelse(anomaly == "Yes", season + trend, observed)) %>%
        dplyr::select(date, metric)

    }

    data <-
      data %>%
      dplyr::select(metric) %>%
      tidyr::nest_legacy(.key = "data.tbl") %>% # nest it
      dplyr::mutate(data.ts = map(.x    = data.tbl, #create ts object
                                  .f    = ts,
                                  start = c(lubridate::year(as.Date(from)), lubridate::month(as.Date(from))),
                                  frequency = 12)
      ) %>%
      dplyr::mutate(fit_ets = purrr::map(data.ts, forecast::ets)) %>%
      dplyr::mutate(summary_ets = purrr::map(fit_ets, summary)) %>%
      dplyr::mutate(mape_ets = purrr::map(summary_ets, 5)) %>%
      dplyr::mutate(rmse_ets = purrr::map(summary_ets, 2)) %>%
      dplyr::mutate(fit.arima = purrr::map(data.ts, forecast::auto.arima)) %>%
      dplyr::mutate(summary_arima = purrr::map(fit.arima, summary)) %>%
      dplyr::mutate(mape_arima = purrr::map(summary_arima, 5)) %>%
      dplyr::mutate(rmse_arima = purrr::map(summary_arima, 2)) %>%

      dplyr::mutate(final_model = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), fit.arima, fit_ets),
                    final_model_type = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), "ARIMA", "Exp. Smoothing"),
                    final_model_mape = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), as.numeric(mape_arima), as.numeric(mape_ets)),
                    final_model_rmse = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), as.numeric(rmse_arima), as.numeric(rmse_ets))) %>%

      dplyr::mutate(predict = purrr::map(final_model, forecast::forecast, h = forecasts)) %>%
      dplyr::mutate(sweep = purrr::map(predict, sweep::sw_sweep, fitted = TRUE)) %>%
      tidyr::unnest_legacy(sweep, .preserve = c(final_model_type, final_model_mape, final_model_rmse)) %>%
      dplyr::mutate(date = c(seq(as.Date(lubridate::floor_date(from, unit = periods)), as.Date(floor_date(to, unit = periods)), by = periods),
                             seq(as.Date(lubridate::floor_date(from, unit = periods)), as.Date(floor_date(to, unit = periods)) + months(forecasts), by = periods)),
                    metric = round(metric, 0),
                    lo.80 = round(lo.80, 0),
                    hi.80 = round(hi.80, 0),
                    lo.95 = round(lo.95, 0),
                    hi.95 = round(hi.95, 0),
                    final_model_mape = round(final_model_mape, 1),
                    final_model_rmse = round(final_model_rmse, 0),
                    timeperiod = "month") %>%
      dplyr::rename("finalmodeltype" = "final_model_type",
                    "finalmodelmape" = "final_model_mape",
                    "finalmodelrmse" = "final_model_rmse",
                    "type" = "key",
                    "lo80" = "lo.80",
                    "lo95" = "lo.95",
                    "hi80" = "hi.80",
                    "hi95" = "hi.95") %>%
      dplyr::mutate(date = as.character(date),
                    type = dplyr::if_else(type == "actual", "actual", "forecast")) %>%
      dplyr::mutate(anomaly = dplyr::if_else(anomaly == TRUE, "ON", "OFF")) %>%
      dplyr::select(-index)

  }  else if (periods == "year") {


    # _Year -------------------------------------------------------------------

    # periods = "year"

    data <-
      final_dataset %>%
      dplyr::mutate(date = lubridate::floor_date(as.Date(date), unit = periods)) %>%
      dplyr::group_by(date, .drop = FALSE) %>%
      dplyr::summarise(metric = sum(metric)) %>%
      dplyr::ungroup() %>%
      dplyr::full_join(data.frame(date = seq(as.Date(lubridate::floor_date(from, unit = periods)), as.Date(lubridate::floor_date(to, unit = periods)), by = periods))) %>%
      dplyr::arrange(date) %>%
      tidyr::replace_na(list(metric = na_values(.$metric, na.rm = TRUE))) %>%
      dplyr::mutate(metric = dplyr::if_else(metric == 0, dplyr::lag(metric), metric))



    # Run when anomaly is selected
    if (anomaly == TRUE) {

      # test1 <- data.frame(date = seq.Date(from = as.Date('2010-01-01'), to = as.Date('2010-01-12'), by = 1), metric = c(3500,4761,4800,4900, 5000, 5050,4000, 3000, 3500, 3300, 4000, 4555))

      l <-
        forecast::tsoutliers(data$metric)

      new <-
        data.frame(matrix(unlist(l), ncol=length(l)))

      for(i in new$X1){

        data$metric[i] <- new$X2[new$X1 == i]
      }



    }



    data <-
      data %>%
      dplyr::select(metric) %>%
      tidyr::nest_legacy(.key = "data.tbl") %>% # nest it
      dplyr::mutate(data.ts = purrr::map(.x    = data.tbl, #create ts object
                                         .f    = ts,
                                         start = lubridate::year(as.Date(from)))
      ) %>%
      dplyr::mutate(fit_ets = purrr::map(data.ts, forecast::ets)) %>%
      dplyr::mutate(summary_ets = purrr::map(fit_ets, summary)) %>%
      dplyr::mutate(mape_ets = purrr::map(summary_ets, 5)) %>%
      dplyr::mutate(rmse_ets = purrr::map(summary_ets, 2)) %>%
      dplyr::mutate(fit.arima = purrr::map(data.ts, forecast::auto.arima)) %>%
      dplyr::mutate(summary_arima = purrr::map(fit.arima, summary)) %>%
      dplyr::mutate(mape_arima = purrr::map(summary_arima, 5)) %>%
      dplyr::mutate(rmse_arima = purrr::map(summary_arima, 2)) %>%

      dplyr::mutate(final_model = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), fit.arima, fit_ets),
                    final_model_type = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), "ARIMA", "Exp. Smoothing"),
                    final_model_mape = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), as.numeric(mape_arima), as.numeric(mape_ets)),
                    final_model_rmse = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), as.numeric(rmse_arima), as.numeric(rmse_ets))) %>%

      dplyr::mutate(predict = purrr::map(final_model, forecast::forecast, h = forecasts)) %>%
      dplyr::mutate(sweep = map(predict, sweep::sw_sweep, fitted = TRUE)) %>%
      # mutate(sweep = cbind(sweep, 1:228))
      tidyr::unnest_legacy(sweep, .preserve = c(final_model_type, final_model_mape, final_model_rmse)) %>%
      dplyr::mutate(date = c(seq(as.Date(lubridate::floor_date(from, unit = periods)), as.Date(lubridate::floor_date(to, unit = periods)), by = periods),

                             seq(as.Date(lubridate::floor_date(from, unit = periods)), as.Date(lubridate::floor_date(to, unit = periods)) + lubridate::years(forecasts), by = periods)),
                    metric = round(metric, 0),
                    lo.80 = round(lo.80, 0),
                    hi.80 = round(hi.80, 0),
                    lo.95 = round(lo.95, 0),
                    hi.95 = round(hi.95, 0),
                    final_model_mape = round(final_model_mape, 1),
                    final_model_rmse = round(final_model_rmse, 0),
                    timeperiod = "year") %>%
      dplyr::rename("finalmodeltype" = "final_model_type",
                    "finalmodelmape" = "final_model_mape",
                    "finalmodelrmse" = "final_model_rmse",
                    "type" = "key",
                    "lo80" = "lo.80",
                    "lo95" = "lo.95",
                    "hi80" = "hi.80",
                    "hi95" = "hi.95") %>%
      dplyr::mutate(date = as.character(date),
                    type = dplyr::if_else(type == "actual", "actual", "forecast")) %>%
      dplyr::mutate(anomaly = dplyr::if_else(anomaly == TRUE, "ON", "OFF")) %>%
      dplyr::select(-index)

    # _Day -------------------------------------------------------------------

  } else if (periods == "day") {

    # periods = "day"

    data <-
      final_dataset %>%
      dplyr::filter(date >= as.Date(from) & date <= as.Date(to)) %>%
      dplyr::mutate(date = lubridate::floor_date(as.Date(date), unit = periods)) %>%
      # dplyr::filter(date >= from & date <= to) %>%
      dplyr::group_by(date, .drop = FALSE) %>%
      dplyr::summarise(metric = sum(metric)) %>%
      dplyr::ungroup() %>%
      dplyr::full_join(data.frame(date = seq(lubridate::floor_date(as.Date(from), unit = periods), lubridate::floor_date(as.Date(to), unit = periods), by = periods))) %>%
      dplyr::arrange(date) %>%
      tidyr::replace_na(list(metric = na_values(.$metric, na.rm = TRUE))) %>%
      dplyr::mutate(metric = dplyr::if_else(metric == 0, dplyr::lag(metric), metric))



    # Run when anomaly is selected
    if (anomaly == TRUE) {

      # test1 <- data.frame(date = seq.Date(from = as.Date('2010-01-01'), to = as.Date('2010-01-12'), by = 1), metric = c(3500,4761,4800,4900, 5000, 5050,4000, 3000, 3500, 3300, 4000, 4555))

      l <-
        forecast::tsoutliers(data$metric)

      new <-
        data.frame(matrix(unlist(l), ncol=length(l)))

      for(i in new$X1){

        data$metric[i] <- new$X2[new$X1 == i]
      }



    }

    data <-
      data %>%
      dplyr::select(metric) %>%
      tidyr::nest_legacy(.key = "data.tbl") %>% # nest it
      dplyr::mutate(data.ts = map(.x    = data.tbl, #create ts object
                                  .f    = ts,
                                  start = lubridate::yday(as.Date(from)),
                                  # frequency = 365.25)
                                  frequency = 7)
      ) %>%
      dplyr::mutate(fit_ets = purrr::map(data.ts, forecast::ets)) %>%
      dplyr::mutate(summary_ets = purrr::map(fit_ets, summary)) %>%
      dplyr::mutate(mape_ets = purrr::map(summary_ets, 5)) %>%
      dplyr::mutate(rmse_ets = purrr::map(summary_ets, 2)) %>%
      dplyr::mutate(fit.arima = purrr::map(data.ts, forecast::auto.arima)) %>%
      dplyr::mutate(summary_arima = purrr::map(fit.arima, summary)) %>%
      dplyr::mutate(mape_arima = purrr::map(summary_arima, 5)) %>%
      dplyr::mutate(rmse_arima = purrr::map(summary_arima, 2)) %>%

      dplyr::mutate(final_model = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), fit.arima, fit_ets),
                    final_model_type = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), "ARIMA", "Exp. Smoothing"),
                    final_model_mape = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), as.numeric(mape_arima), as.numeric(mape_ets)),
                    final_model_rmse = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), as.numeric(rmse_arima), as.numeric(rmse_ets))) %>%

      dplyr::mutate(predict = purrr::map(final_model, forecast::forecast, h = forecasts)) %>%
      dplyr::mutate(sweep = map(predict, sweep::sw_sweep, fitted = TRUE)) %>%
      tidyr::unnest_legacy(sweep, .preserve = c(final_model_type, final_model_mape, final_model_rmse))

    date <-  c(seq(as.Date(from), as.Date(to), by = periods),
               seq(as.Date(from), as.Date(to) + lubridate::weeks(forecasts), by = periods))

    date <- date[1:nrow(data)]

    data <-
      data %>%
      dplyr::mutate(date = date,
                    metric = round(metric, 0),
                    lo.80 = round(lo.80, 0),
                    hi.80 = round(hi.80, 0),
                    lo.95 = round(lo.95, 0),
                    hi.95 = round(hi.95, 0),
                    final_model_mape = round(final_model_mape, 1),
                    final_model_rmse = round(final_model_rmse, 0),
                    timeperiod = "day") %>%
      dplyr::rename("finalmodeltype" = "final_model_type",
                    "finalmodelmape" = "final_model_mape",
                    "finalmodelrmse" = "final_model_rmse",
                    "type" = "key",
                    "lo80" = "lo.80",
                    "lo95" = "lo.95",
                    "hi80" = "hi.80",
                    "hi95" = "hi.95") %>%
      dplyr::mutate(date = as.character(date),
                    type = dplyr::if_else(type == "actual", "actual", "forecast")) %>%
      dplyr::mutate(anomaly = dplyr::if_else(anomaly == TRUE, "ON", "OFF")) %>%
      dplyr::select(-index)



  }  else if (periods == "week") {

    # _Week -------------------------------------------------------------------

    # periods = "week"


    from <- lubridate::floor_date(as.Date(from), unit = 'week', week_start = 1)
    to <- lubridate::floor_date(as.Date(to), unit = 'week', week_start = 1)

    data <-
      final_dataset %>%

      dplyr::filter(date >= as.Date(from) & date <= as.Date(to)) %>%

      dplyr::mutate(date = lubridate::floor_date(as.Date(date), unit = periods,  week_start = 1)) %>%
      # dplyr::filter(date >= from & date <= to) %>%
      dplyr::group_by(date, .drop = FALSE) %>%
      dplyr::summarise(metric = sum(metric)) %>%
      dplyr::ungroup() %>%
      dplyr::full_join(data.frame(date = seq(as.Date(lubridate::floor_date(as.Date(from), unit = 'week', week_start = 1)), as.Date(to), by = periods))) %>%
      dplyr::arrange(date) %>%
      tidyr::replace_na(list(metric = na_values(.$metric, na.rm = TRUE))) %>%
      dplyr::mutate(metric = dplyr::if_else(metric == 0, dplyr::lag(metric), metric)) %>%
      dplyr::mutate(metric = dplyr::if_else(is.na(metric) == TRUE, dplyr::lead(metric), metric))


    # Run when anomaly is selected
    if (anomaly == TRUE) {


      l <-
        forecast::tsoutliers(data$metric)

      new <-
        data.frame(matrix(unlist(l), ncol=length(l)))

      for(i in new$X1){

        data$metric[i] <- new$X2[new$X1 == i]
      }



    }

    data <-
      data %>%
      dplyr::select(metric) %>%
      tidyr::nest_legacy(.key = "data.tbl") %>% # nest it
      dplyr::mutate(data.ts = map(.x    = data.tbl, #create ts object
                                  .f    = ts,
                                  start = c(lubridate::year(as.Date(from)), lubridate::week(as.Date(from))),
                                  frequency = 52)
      ) %>%
      dplyr::mutate(fit_ets = purrr::map(data.ts, forecast::ets)) %>%
      dplyr::mutate(summary_ets = purrr::map(fit_ets, summary)) %>%
      dplyr::mutate(mape_ets = purrr::map(summary_ets, 5)) %>%
      dplyr::mutate(rmse_ets = purrr::map(summary_ets, 2)) %>%
      dplyr::mutate(fit.arima = purrr::map(data.ts, forecast::auto.arima)) %>%
      dplyr::mutate(summary_arima = purrr::map(fit.arima, summary)) %>%
      dplyr::mutate(mape_arima = purrr::map(summary_arima, 5)) %>%
      dplyr::mutate(rmse_arima = purrr::map(summary_arima, 2)) %>%

      dplyr::mutate(final_model = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), fit.arima, fit_ets),
                    final_model_type = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), "ARIMA", "Exp. Smoothing"),
                    final_model_mape = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), as.numeric(mape_arima), as.numeric(mape_ets)),
                    final_model_rmse = dplyr::if_else(as.numeric(mape_arima) <= as.numeric(mape_ets), as.numeric(rmse_arima), as.numeric(rmse_ets))) %>%

      dplyr::mutate(predict = purrr:::map(final_model, forecast::forecast, h = forecasts)) %>%
      dplyr::mutate(sweep = map(predict, sweep::sw_sweep, fitted = TRUE)) %>%
      # mutate(sweep = cbind(sweep, 1:228))
      tidyr::unnest_legacy(sweep, .preserve = c(final_model_type, final_model_mape, final_model_rmse))

    date <-  c(seq(as.Date(from), as.Date(to), by = periods),
               seq(as.Date(from), as.Date(to) + lubridate::weeks(forecasts), by = periods))

    date <- date[1:nrow(data)]

    data <-
      data %>%
      dplyr::mutate(date = date,
                    metric = round(metric, 0),
                    lo.80 = round(lo.80, 0),
                    hi.80 = round(hi.80, 0),
                    lo.95 = round(lo.95, 0),
                    hi.95 = round(hi.95, 0),
                    final_model_mape = round(final_model_mape, 1),
                    final_model_rmse = round(final_model_rmse, 0),
                    timeperiod = "week") %>%
      dplyr::rename("finalmodeltype" = "final_model_type",
                    "finalmodelmape" = "final_model_mape",
                    "finalmodelrmse" = "final_model_rmse",
                    "type" = "key",
                    "lo80" = "lo.80",
                    "lo95" = "lo.95",
                    "hi80" = "hi.80",
                    "hi95" = "hi.95") %>%
      dplyr::mutate(date = as.character(date),
                    type = dplyr::if_else(type == "actual", "actual", "forecast")) %>%
      dplyr::mutate(anomaly = dplyr::if_else(anomaly == TRUE, "ON", "OFF")) %>%
      dplyr::select(-index)




  }
}


