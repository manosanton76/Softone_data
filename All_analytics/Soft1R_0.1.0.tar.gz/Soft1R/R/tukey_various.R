



#' Multiple Tukey tests
#'
#' @description
#' Perform multiple Tukey tests using all levels of the categorical variables
#'
#' @param dataset Specify the dataframe
#' @param kpi Specify the KPI variable (Must be included in the dataframe)
#' @param categorical Specify a vector of categorical variables (Must be included in the dataframe)
#'
#' @details
#'
#' - It returns a dataframe with multiple comparison of Tukey's range test on all levels of the categorical variables.
#' - Anova returns the statistical significance of at least one level has significant difference in variance.
#'
#' @examples
#'
#' library(tidyverse)
#'
#' t <- tukey_various(iris, "Sepal.Length", c("Species"))
#' t
#'
#' @export


tukey_various <- function(dataset, kpi, categorical) {

  l <- list()
  for (i in 1:length(categorical)){

    l[[categorical[i]]] <- stats::TukeyHSD(stats::aov(dataset[[kpi]] ~ dataset[[categorical[i]]]))[[1]] %>% base::as.data.frame() %>%
      tibble::rownames_to_column("Vars") %>%
      dplyr::mutate(Variable = categorical[i])

  }

  new <-
    base::as.data.frame(base::do.call(base::rbind, l)) %>%
    dplyr::arrange(Variable, `p adj`)
}
