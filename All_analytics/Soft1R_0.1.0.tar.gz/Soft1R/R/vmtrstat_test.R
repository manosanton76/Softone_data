#' Test dataset for forecasting (forecast_dataset_s1)
#'
#' This dataset was generated from a sales transactions dataset (Soft1 demo) in azure data
#' lake and it can be used with forecast_dataset_s1() to apply forecasting
#'
#'
#' @examples
#' vmtrstat_test
#'
"vmtrstat_test"
