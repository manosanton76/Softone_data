


#' Downloads specific folder & create the dataset
#'
#' @description
#' At first it downloads all zip files from specific folder in SoftOne azure
#' datalake, perform all appropriate ETL steps (unzip, concatenate csv's, delete empty rows etc.)
#' & finally creates the dataset
#'
#' @details
#'
#' - It only works if there is already an authorized access to the datalake (token, installation, temp files etc. )
#'
#'
#' @examples
#' \dontrun{
#'
#' library(Soft1R)
#' library(tidyverse)
#' library(lubridate)
#'
#' Items <- download_folder("/Items/")
#' Items
#' }
#'
#' @export
#'

download_folder <- function(folder) {


  # Download transactional datasets
  AzureStor::multidownload_adls_file(fs, src = paste(folder, "*.*", sep = ""), dest = paste(tempdir(), temp_path, "/data", folder, sep = ""), overwrite = TRUE)

  # Read data in R
  zipfiles <- list.files(path = paste(tempdir(), temp_path, "/data", folder, sep = ""), pattern = "*.zip", full.names = TRUE) # data frame of zip files in current directory

  for (i in seq_along(zipfiles)) {

    utils::unzip(zipfiles[i], exdir = paste(tempdir(), temp_path, "/data", folder, "csv_", sep = ""))

  }

  # Delete empty csv files
  for (i in list.files(path = paste(tempdir(), temp_path, "/data", folder, "csv_", sep = ""), pattern="*.csv", full.names = TRUE)){
    if (nrow(data.table::fread(i)) <= 1) {unlink(i)}
  }


  files = list.files(path = paste(tempdir(), temp_path, "/data", folder, "csv_", sep = ""), pattern="*.csv", full.names = TRUE)

  # Create dataframe
  temp <-
    data.table::rbindlist(lapply(files, data.table::fread, colClasses=list(character=1:ncol(data.table::fread(files[1]))), skip = 2)) %>%
    dplyr::as_tibble() %>%
    rename_with(~ names(data.table::fread(files[1])))

  return(temp)
}
