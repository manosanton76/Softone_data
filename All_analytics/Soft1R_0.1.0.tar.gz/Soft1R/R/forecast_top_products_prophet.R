

#' Apply monthly forecasting in the top products using Facebook prophet library
#'
#' @description
#' It produces monthly forecasts the top products (in sales last 2 years)
#'
#' @param code Soft1 installation code
#' @param datalake Which Azure data lake to use (0 for production)
#'
#' @details
#'
#' - Must provide a valid Soft1 installation code i.e. must have data in azure data lake
#' - Use 0 on datalake, for storing results on the production Azure data lake.
#' Use 1 (default) for the dev Azure data lake
#'
#'
#' @examples
#' \dontrun{
#'
#' library(tidyverse)
#' library(lubridate)
#' library(prophet)
#' library(tidyquant)
#' library(AzureAuth)
#' library(AzureStor)
#' library(data.table)
#'
#' forecast_top_products_prophet(code = "01100201021801", datalake = 1)
#'
#' }
#'
#' @export
#'

forecast_top_products_prophet <- function(code, datalake = 1) {


  ptm <- proc.time()


  # 1. Get Access to Azure data lake ---------------------------------------------
  if (datalake == 0 ) {
    token_path <- "https://s1datalakeprod01.blob.core.windows.net"
    main_path <- "https://s1datalakeprod01.dfs.core.windows.net"
  } else {
    token_path <- "https://s1azdatalake01.blob.core.windows.net"
    main_path <- "https://s1azdatalake01.dfs.core.windows.net"
  }


  token <- AzureAuth::get_azure_token(token_path, "f99f92d3-7e2b-4820-858a-b629fad639e0", "b684d32b-6c1e-4538-af61-d19a1921ec80",
                                      password="RGG7Q~v4iXb4btVT47_pMkG0e8Sn_gDwK3DOw", auth_type="client_credentials")

  ad_endp_tok <- AzureStor::storage_endpoint(main_path, token=token)

  cont <- AzureStor::storage_container(ad_endp_tok, code)

  files <- AzureStor::list_storage_files(cont)

  fs <- AzureStor::adls_filesystem(paste(main_path, "/", code, sep = ""), token=token)

  # 1.1 Set up working directory & folders -------------------------------------

  temp_path <- "/forecast_top_products_prophet"
  dir.create(paste(tempdir(), "/forecast_top_products_prophet/", sep = ""))


  dir.create(paste(tempdir(), temp_path, "/upload/", sep = ""))
  dir.create(paste(tempdir(), temp_path, "/data/", sep = ""))

  # 1.2 Upload Empty files -----------------------------------------------------

  # 1.2.1 Create empty detail data objects -------------------------------------
  data_types <-
    structure(list(finalmodeltype = "string",
                   finalmodelerror = "string",
                   actual = "float",
                   forecast = "float",
                   date = "datetime",
                   timeperiod = "string",
                   anomaly = "string",
                   datetimecreated = "datetime",
                   itemid = "string"), class = c("tbl_df", "tbl", "data.frame"), row.names = c(NA, -1L))

  readr::write_csv2(data_types, path = paste(tempdir(), temp_path, "/upload", "/ForecastingPerProductProphetAllCompanies.csv", sep = ""), na = "", )

  # 1.2.2 Create empty zip files -----------------------------------------------

  dir.create(paste(tempdir(), temp_path, "/upload/ForecastingPerProductProphetAllCompanies", sep = ""))

  system(paste("zip -9 -y -j -q ", tempdir(), temp_path, "/upload/ForecastingPerProductProphetAllCompanies/ForecastingPerProductProphetAllCompanies.zip", " ", tempdir(), temp_path, "/upload/ForecastingPerProductProphetAllCompanies.csv", sep = ""))


  # 1.2.3 Upload empty zip files  ----------------------------------------------

  AzureStor::storage_multiupload(cont, paste(tempdir(), temp_path, "/upload/", "/ForecastingPerProductProphetAllCompanies/*.zip", sep = ""), "ForecastingPerProductProphetAllCompanies")  # uploading everything in a directory

  # 2. Download transactional datasets -----------------------------------------

  AzureStor::multidownload_adls_file(fs, src = "/SalesTransactions/*.*", dest = paste(tempdir(), temp_path, "/data/", sep = ""), overwrite = TRUE)


  # 3. Read dataset in R ---------------------------------------------------------
  zipfiles <- list.files(path = paste(tempdir(), temp_path, "/data/", sep = ""), pattern = "*.zip", full.names = TRUE) # data frame of zip files in current directory


  for (i in seq_along(zipfiles)) {

    utils::unzip(zipfiles[i], exdir = paste(tempdir(), temp_path, "/data/csv", sep = ""))

  }

  # Delete empty csv files
  for (i in list.files(path = paste(tempdir(), temp_path, "/data/csv", sep = ""), pattern="*.csv", full.names = TRUE)){
    if (nrow(data.table::fread(i)) <= 1) {unlink(i)}
  }


  files = list.files(path = paste(tempdir(), temp_path, "/data/csv", sep = ""), pattern="*.csv", full.names = TRUE)

  vmtrstat <<-
    data.table::rbindlist(lapply(files, data.table::fread, colClasses=list(character=1:ncol(data.table::fread(files[1]))), skip = 2)) %>%
    dplyr::as_tibble() %>%
    rename_with(~ names(data.table::fread(files[1]))) %>%
    filter(itemid != "") %>%
    select(cmpcode, date, custid, itemid, salesval, salesqty1)

  # names(vmtrstat2) <- names(data.table::fread(files[1]))


  vmtrstat <<-
    vmtrstat %>%
    dplyr::mutate(
      salesval = as.numeric(gsub(",", ".", salesval)),
      salesqty = as.numeric(gsub(",", ".", salesqty1)),
      date = with_tz(as_datetime(as.POSIXct(as_datetime(vmtrstat$date), tz="Europe/London")), tzone = "Europe/Athens"),
      date = as.Date(as.character(date))
    ) %>%
    dplyr::mutate(itemid = paste(cmpcode, itemid, sep = "-"))

  # Filter out non-complete months
  differ <- as.integer((lubridate::ceiling_date(max(vmtrstat$date), unit = "month") - 1) -  max(vmtrstat$date))
  if (differ > 0) {
    filter_date <- lubridate::floor_date(max(vmtrstat$date), unit = "month")
    vmtrstat <<- vmtrstat %>% filter(date < filter_date)
  }


  # 4. Forecast quantity top products month  -----------------------------------

  items <-
    vmtrstat %>%
    dplyr::group_by(itemid) %>%
    dplyr::count() %>%
    dplyr::arrange(-n) %>%
    dplyr::ungroup() %>%
    dplyr::do(head(., 1000)) %>%
    dplyr::pull(itemid)

  tb1 <-
    vmtrstat %>%
    dplyr::filter(itemid %in% items) %>%
    dplyr::mutate(itemid = ifelse(itemid == "", "None", itemid)) %>%
    dplyr::mutate_at(vars(itemid), factor) %>%
    dplyr::group_by(itemid, ds = floor_date(date, unit = "month"))  %>%
    dplyr::summarise(y = sum(salesqty)) %>%
    dplyr::ungroup() %>%
    tidyr::pivot_wider(names_from = itemid,
                values_from = y) %>%
    dplyr::arrange(ds) %>%
    replace(is.na(.), 0)


  # with some dplyr and base R you can transform each time series in a data frame within a list
  ts_list <- tb1 %>%
    tidyr::gather("type", "y", -ds) %>%
    split(.$type)
  # this just removes the type column that we don't need anymore
  ts_list <- lapply(ts_list, function(x) { x["type"] <- NULL; x })


  m_list <- purrr::map(ts_list, prophet::prophet) # prophet call

  future_list <- purrr::map(m_list, prophet::make_future_dataframe, periods = 12, freq = "month") # makes future obs

  forecast_list <- purrr::map2(m_list, future_list, predict) # map2 because we have two inputs


  new <- do.call(rbind, forecast_list) %>%
    tibble::rownames_to_column(var = "itemid") %>%
    tidyr::separate(itemid, c('itemid', 'orderid'), sep = "\\.")

  tb2 <-
    tb1 %>%
    tidyr::pivot_longer(!ds, names_to = "itemid", values_to = "actual") %>%
    dplyr::arrange(itemid, ds)

  final <-
    new %>%
    dplyr::left_join(tb2, by = c("itemid" = "itemid", "ds" = "ds")) %>%
    dplyr::select(itemid, orderid, ds, yhat, actual) %>%
    dplyr::mutate(yhat = round(yhat, 0)) %>%
    dplyr::mutate(error = round(abs(actual-yhat)/(abs(actual) + abs(yhat)), 4)) %>%
    dplyr::mutate(error = ifelse(is.infinite(error) == TRUE | is.nan(error) == TRUE, NA, error))

  test <-
    final %>%
    dplyr::group_by(itemid) %>%
    dplyr::summarise(finalmodelerror = round(median(error, na.rm = TRUE), 4)*100) %>%
    stats::na.omit()

  final <-
    final %>%
    dplyr::left_join(test) %>%
    dplyr::mutate(finalmodeltype = "Prophet",
           timeperiod = "month",
           anomaly = "OFF",
           datetimecreated = paste(as.character(lubridate::format_ISO8601(Sys.time())), ".000Z", sep = ""),
           date = paste(as.character(lubridate::format_ISO8601(as.POSIXct(ds))), ".000Z", sep = "")) %>%
    select(finalmodeltype, finalmodelerror, actual, forecast = yhat, date, timeperiod, anomaly, datetimecreated, itemid)


  new_per_product <-
    as.data.frame(final) %>%
    dplyr::mutate_if(is.numeric, decimal_sep)


  # 6. Update detail data objects ----------------------------------------------

  utils::write.table(new_per_product, file = paste(tempdir(), temp_path, "/upload", "/ForecastingPerProductProphetAllCompanies.csv", sep = ""), sep = ";", na = "", quote=c(1, 2, 6, 7, 9), row.names = FALSE, col.names = FALSE, append = TRUE)

  # 7. Update the zip files ----------------------------------------------------

  system(paste("zip -9 -y -j -q ", tempdir(), temp_path, "/upload/ForecastingPerProductProphetAllCompanies/ForecastingPerProductProphetAllCompanies.zip", " ", tempdir(), temp_path, "/upload/ForecastingPerProductProphetAllCompanies.csv", sep = ""))

  # 8. Upload updated zip files  -----------------------------------

  AzureStor::storage_multiupload(cont, paste(tempdir(), temp_path, "/upload/", "/ForecastingPerProductProphetAllCompanies/*.zip", sep = ""), "ForecastingPerProductProphetAllCompanies")  # uploading everything in a directory

  # 9. Create log files --------------------------------------------------------

  time_n <- proc.time() - ptm

  time_now2 <- as.character(format(Sys.time(), "%Y_%m_%d_%H_%M_%S"))


  product_forecasts <-
    new_per_product %>%
    group_by(timeperiod, anomaly, itemid) %>%
    summarise(finalmodeltype = first(finalmodeltype),
              finalmodelerror = first(finalmodelerror)) %>%
    mutate(code = code,
           date = time_now2,
           vmtrstat_rows = nrow(vmtrstat),
           customers = length(unique(vmtrstat$custid)),
           products = length(unique(vmtrstat$itemid)),
           duration =   round(as.numeric(time_n[3]), 1))

  dir.create("./Logs", showWarnings = FALSE)

  write.csv2(product_forecasts, file = paste0("./Logs/", time_now2, "_Forecasts_Products_Prophet.csv", sep = ""), row.names = FALSE)

  # Define the blob storage
  cont <- AzureStor::blob_container(
    "https://softonebilogs.blob.core.windows.net/softonebilogs",
    sas="sp=racwli&st=2022-04-01T13:42:50Z&se=2022-12-31T22:42:50Z&spr=https&sv=2020-08-04&sr=c&sig=mIpQrdjrjRmaOeWxR8j24k%2BVtH1JjajPk5CtOi6s9Cs%3D")


  AzureStor::upload_blob(cont, paste0("./Logs/", time_now2, "_Forecasts_Products_Prophet.csv", sep = ""))

  # 10. Clean disk -------------------------------------------------------------
  unlink(paste(tempdir(), temp_path, sep = ""), recursive = T)

}
