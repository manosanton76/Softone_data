library(testthat)
library(Soft1R)

library(tidyverse)
library(lubridate)
# library(lattice)

test_check("Soft1R")
