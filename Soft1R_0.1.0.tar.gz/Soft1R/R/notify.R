


#' Push notifications with Pushover
#'
#' @description
#' Create push notifications using the pushover application on the mobile phone
#'
#' @param message Specify the message
#'
#' @details
#'
#' - It will sent a push notification (printing input) to the mobile phone using pushover notification
#'
#' @examples
#' \dontrun{
#' library(pushoverr)
#'
#' notify("Test notification")
#'}
#'
#' @export


notify <- function(message){

  pushoverr::pushover(message = message, user = "ugVBBF3Tko4acTeQMU7shB8Zm7LD7J", app = "aWBqaCXeJHkt6vDNF8KKtXFuPQDQDo")

}
