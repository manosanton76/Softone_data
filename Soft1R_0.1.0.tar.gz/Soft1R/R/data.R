#' Test dataset for clustering (cluster_s1)
#'
#' This dataset was generated from a sales transactions dataset (Soft1 demo) in azure data
#' lake and it can be used with cluster_s1() to apply clustering
#'
#' @examples
#' cluster_data_test
#'
#'
"cluster_data_test"

