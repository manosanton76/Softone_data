

#' Apply monthly forecasting in the top products
#'
#' @description
#' It produces monthly forecasts the top products (in sales last 2 years)
#'
#' @param code Soft1 installation code
#' @param datalake Which Azure data lake to use (0 for production)
#'
#' @details
#'
#' - Must provide a valid Soft1 installation code i.e. must have data in azure data lake
#' - Use 0 on datalake, for storing results on the production Azure data lake.
#' Use 1 (default) for the dev Azure data lake
#'
#'
#' @examples
#' \dontrun{
#'
#' library(tidyverse)
#' library(lubridate)
#' library(forecast)
#' library(sweep)
#' library(tidyquant)
#' library(AzureAuth)
#' library(AzureStor)
#' library(data.table)
#' library(parsedate)
#' library(anomalize)
#'
#' forecast_top_products(code = "01100201021801", datalake = 1)
#'
#' }
#'
#' @export
#'

forecast_top_products <- function(code, datalake = 1) {


ptm <- proc.time()


# 1. Get Access to Azure data lake ---------------------------------------------
if (datalake == 0 ) {
  token_path <- "https://s1datalakeprod01.blob.core.windows.net"
  main_path <- "https://s1datalakeprod01.dfs.core.windows.net"
} else {
  token_path <- "https://s1azdatalake01.blob.core.windows.net"
  main_path <- "https://s1azdatalake01.dfs.core.windows.net"
}


token <- AzureAuth::get_azure_token(token_path, "f99f92d3-7e2b-4820-858a-b629fad639e0", "b684d32b-6c1e-4538-af61-d19a1921ec80",
                                    password="RGG7Q~v4iXb4btVT47_pMkG0e8Sn_gDwK3DOw", auth_type="client_credentials")

ad_endp_tok <- AzureStor::storage_endpoint(main_path, token=token)

cont <- AzureStor::storage_container(ad_endp_tok, code)

files <- AzureStor::list_storage_files(cont)

fs <- AzureStor::adls_filesystem(paste(main_path, "/", code, sep = ""), token=token)

# 1.1 Set up working directory & folders -------------------------------------

temp_path <- "/forecast_top_products"
dir.create(paste(tempdir(), "/forecast_top_products/", sep = ""))


dir.create(paste(tempdir(), temp_path, "/upload/", sep = ""))
dir.create(paste(tempdir(), temp_path, "/data/", sep = ""))

# 1.2 Upload Empty files -----------------------------------------------------

# 1.2.1 Create empty detail data objects -------------------------------------
data_types <-
  structure(list(finalmodeltype = "string",
                 finalmodelmape = "string",
                 finalmodelrmse = "float",
                 type = "string",
                 metric = "float",
                 lo80 = "float", lo95 = "float",
                 hi80 = "float", hi95 = "float",
                 date = "datetime",
                 timeperiod = "string",
                 anomaly = "string",
                 datetimecreated = "datetime",
                 timeseries = "string",
                 itemid = "string"), class = c("tbl_df", "tbl", "data.frame"), row.names = c(NA, -1L))

readr::write_csv2(data_types, path = paste(tempdir(), temp_path, "/upload", "/ForecastingPerProductAllCompanies.csv", sep = ""), na = "", )

# 1.2.2 Create empty zip files -----------------------------------------------

dir.create(paste(tempdir(), temp_path, "/upload/ForecastingPerProductAllCompanies", sep = ""))

system(paste("zip -9 -y -j -q ", tempdir(), temp_path, "/upload/ForecastingPerProductAllCompanies/ForecastingPerProductAllCompanies.zip", " ", tempdir(), temp_path, "/upload/ForecastingPerProductAllCompanies.csv", sep = ""))


# 1.2.3 Upload empty zip files  ----------------------------------------------

AzureStor::storage_multiupload(cont, paste(tempdir(), temp_path, "/upload/", "/ForecastingPerProductAllCompanies/*.zip", sep = ""), "ForecastingPerProductAllCompanies")  # uploading everything in a directory

# 2. Download transactional datasets -----------------------------------------

AzureStor::multidownload_adls_file(fs, src = "/SalesTransactions/*.*", dest = paste(tempdir(), temp_path, "/data/", sep = ""), overwrite = TRUE)


# 3. Read dataset in R ---------------------------------------------------------
zipfiles <- list.files(path = paste(tempdir(), temp_path, "/data/", sep = ""), pattern = "*.zip", full.names = TRUE) # data frame of zip files in current directory


for (i in seq_along(zipfiles)) {

  utils::unzip(zipfiles[i], exdir = paste(tempdir(), temp_path, "/data/csv", sep = ""))

}

# Delete empty csv files
for (i in list.files(path = paste(tempdir(), temp_path, "/data/csv", sep = ""), pattern="*.csv", full.names = TRUE)){
  if (nrow(data.table::fread(i)) <= 1) {unlink(i)}
}


files = list.files(path = paste(tempdir(), temp_path, "/data/csv", sep = ""), pattern="*.csv", full.names = TRUE)

vmtrstat <<-
  data.table::rbindlist(lapply(files, data.table::fread, colClasses=list(character=1:ncol(data.table::fread(files[1]))), skip = 2)) %>%
  dplyr::as_tibble() %>%
  rename_with(~ names(data.table::fread(files[1]))) %>%
  filter(itemid != "") %>%
  select(cmpcode, date, custid, itemid, salesval, salesqty1)

# names(vmtrstat2) <- names(data.table::fread(files[1]))


vmtrstat <<-
  vmtrstat %>%
  dplyr::mutate(
    salesval = as.numeric(gsub(",", ".", salesval)),
    salesqty = as.numeric(gsub(",", ".", salesqty1)),
    date = with_tz(as_datetime(as.POSIXct(as_datetime(vmtrstat$date), tz="Europe/London")), tzone = "Europe/Athens"),
    date = as.Date(as.character(date))
  ) %>%
  dplyr::mutate(itemid = paste(cmpcode, itemid, sep = "-"))

# Filter out non-complete months
differ <- as.integer((lubridate::ceiling_date(max(vmtrstat$date), unit = "month") - 1) -  max(vmtrstat$date))
if (differ > 0) {
  filter_date <- lubridate::floor_date(max(vmtrstat$date), unit = "month")
  vmtrstat <<- vmtrstat %>% filter(date < filter_date)
}


# 4. Forecast quantity top products month+anomaly  -----------------------------

top_products <-
  vmtrstat %>%
  filter(date > floor_date(max(date), unit = "month") - months(18)) %>%
  group_by(itemid) %>%
  summarise(sales = sum(salesval)) %>%
  arrange(-sales) %>%
  pull(itemid)


l <- list()


foreach(i=1:ifelse(length(top_products) > 20, 20, length(top_products)), .errorhandling = 'remove') %do% {


  test <-
    Soft1R::forecast_dataset_s1(final_dataset = vmtrstat %>% dplyr::filter(itemid == top_products[i]), col = salesqty, periods = "month", forecasts = lubridate::interval(max(vmtrstat$date), lubridate::floor_date(max(vmtrstat$date) + lubridate::years(2), unit = "year") - 1) %/% months(1), from = as.Date(min(vmtrstat$date)), to = as.Date(max(vmtrstat$date))) %>%
    # dplyr::bind_rows(Soft1R::forecast_dataset_s1(final_dataset = vmtrstat %>% dplyr::filter(itemid == top_products[i]), col = salesqty, periods = "month", forecasts = lubridate::interval(max(vmtrstat$date), lubridate::floor_date(max(vmtrstat$date) + lubridate::years(2), unit = "year") - 1) %/% months(1), from = as.Date(min(vmtrstat$date)), to = as.Date(max(vmtrstat$date)), anomaly = TRUE)) %>%
    # dplyr::bind_rows(Soft1R::forecast_dataset_s1(final_dataset = vmtrstat %>% dplyr::filter(itemid == top_products[i]), col = salesqty, periods = "week", forecasts = 25, from = as.Date(min(vmtrstat$date)), to = as.Date(max(vmtrstat$date)))) %>%
    dplyr::mutate(datetimecreated = paste(as.character(lubridate::format_ISO8601(Sys.time())), ".000Z", sep = ""),
                  timeseries = dplyr::if_else(as.Date(date) <= max(vmtrstat$date) & type == "forecast", "secondary", "primary"),
                  date = paste(as.character(lubridate::format_ISO8601(as.POSIXct(date))), ".000Z", sep = "")) %>%
    dplyr::mutate(itemid = as.character(top_products[i]))


  l[[top_products[i]]] <- test
}


new_per_product <-
  as.data.frame(do.call(rbind, l)) %>%
  dplyr::mutate_if(is.numeric, decimal_sep)


# 6. Update detail data objects ----------------------------------------------

utils::write.table(new_per_product, file = paste(tempdir(), temp_path, "/upload", "/ForecastingPerProductAllCompanies.csv", sep = ""), sep = ";", na = "", quote=c(1, 2, 4, 11, 12, 14, 15), row.names = FALSE, col.names = FALSE, append = TRUE)

# 7. Update the zip files ----------------------------------------------------

system(paste("zip -9 -y -j -q ", tempdir(), temp_path, "/upload/ForecastingPerProductAllCompanies/ForecastingPerProductAllCompanies.zip", " ", tempdir(), temp_path, "/upload/ForecastingPerProductAllCompanies.csv", sep = ""))

# 8. Upload updated zip files  -----------------------------------

AzureStor::storage_multiupload(cont, paste(tempdir(), temp_path, "/upload/", "/ForecastingPerProductAllCompanies/*.zip", sep = ""), "ForecastingPerProductAllCompanies")  # uploading everything in a directory

# 9. Create log files --------------------------------------------------------

time_n <- proc.time() - ptm

time_now2 <- as.character(format(Sys.time(), "%Y_%m_%d_%H_%M_%S"))


product_forecasts <-
  new_per_product %>%
  group_by(timeperiod, anomaly, itemid) %>%
  summarise(finalmodeltype = first(finalmodeltype),
            finalmodelmape = first(finalmodelmape),
            finalmodelrmse = first(finalmodelrmse)) %>%
  mutate(code = code,
         date = time_now2,
         vmtrstat_rows = nrow(vmtrstat),
         customers = length(unique(vmtrstat$custid)),
         products = length(unique(vmtrstat$itemid)),
         duration =   round(as.numeric(time_n[3]), 1))

dir.create("./Logs", showWarnings = FALSE)

write.csv2(product_forecasts, file = paste0("./Logs/", time_now2, "_Forecasts_Products.csv", sep = ""), row.names = FALSE)

# Define the blob storage
cont <- AzureStor::blob_container(
  "https://softonebilogs.blob.core.windows.net/softonebilogs",
  sas="sp=racwli&st=2022-04-01T13:42:50Z&se=2022-12-31T22:42:50Z&spr=https&sv=2020-08-04&sr=c&sig=mIpQrdjrjRmaOeWxR8j24k%2BVtH1JjajPk5CtOi6s9Cs%3D")


AzureStor::upload_blob(cont, paste0("./Logs/", time_now2, "_Forecasts_Products.csv", sep = ""))

# 10. Clean disk -------------------------------------------------------------
unlink(paste(tempdir(), temp_path, sep = ""), recursive = T)

}
