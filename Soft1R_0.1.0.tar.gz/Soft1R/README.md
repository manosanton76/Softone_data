
<!-- README.md is generated from README.Rmd. Please edit that file -->

# Soft1R

<!-- badges: start -->

<!-- badges: end -->

Connect to various databases, Forecasting & Segmentation on multiple
SoftOne metrics, Provide context for connecting to Azure data lake

## Installation

You can install Soft1R from local file with:

``` r
install.packages('Soft1R_0.1.0.tar.gz', repos = NULL, type = 'source')
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(Soft1R)
## basic example code
```
