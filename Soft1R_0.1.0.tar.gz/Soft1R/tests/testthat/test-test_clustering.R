

test_that("test clustering output with specific values", {


  t <- cluster_s1(final_dataset = cluster_data_test)

  expect_equal(length(unique(t$custid)), 115)

  expect_equal(round(sum(t$totalsales, na.rm = TRUE), 0), 13311623)

  expect_equal(nrow(t), 575)


})
