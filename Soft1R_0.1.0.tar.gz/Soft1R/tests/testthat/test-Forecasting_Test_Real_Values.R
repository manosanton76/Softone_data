


test_that("forecast_dataset_s1 works properly on aggregated actual values", {

  t1 <-
    vmtrstat_test %>%
    mutate(date = floor_date(date, unit = "month")) %>%
    group_by(date) %>%
    summarize(metric = sum(salesval)) %>%
    mutate(date = as.character(date),
           metric = as.numeric(round(metric, 0)))


  t2 <-
    forecast_dataset_s1(final_dataset = vmtrstat_test, periods = "month",
                        from = min(vmtrstat_test$date),
                        to = max(vmtrstat_test$date),
                        forecasts = 12, nas = "mean",
                        anomaly = FALSE, col = salesval) %>%
    filter(type == "actual") %>%
    select(date, metric)

  expect_equal(t1, t2)

  })
